<?php
/* Smarty version 3.1.33, created on 2019-10-31 12:06:12
  from 'C:\wamp64\www\lojavirtual\view\minha_conta.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dbace3407fb69_62333329',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '76cf993c5e9a561b035ee008a1626824d861f627' => 
    array (
      0 => 'C:\\wamp64\\www\\lojavirtual\\view\\minha_conta.tpl',
      1 => 1572523222,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dbace3407fb69_62333329 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h4 class="text-center">Bem vindo a sua área de cliente, no menu acima temos algumas opções para você!</h4><?php }
}
