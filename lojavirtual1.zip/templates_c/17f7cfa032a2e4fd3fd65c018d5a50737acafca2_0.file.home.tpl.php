<?php
/* Smarty version 3.1.33, created on 2019-10-24 21:00:45
  from 'C:\wamp64\www\lojavirtual\view\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5db210fd0e1ec8_52005983',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '17f7cfa032a2e4fd3fd65c018d5a50737acafca2' => 
    array (
      0 => 'C:\\wamp64\\www\\lojavirtual\\view\\home.tpl',
      1 => 1571950835,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db210fd0e1ec8_52005983 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
    <head>
        <title><?php echo $_smarty_tpl->tpl_vars['SITE_NOME']->value;?>
</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <div align="CENTER">
            <img src="<?php echo $_smarty_tpl->tpl_vars['BANNER']->value;?>
" alt="" class="img img-responsive img-rounded" >
            <hr>
        </div>
    </body>
</html>



<?php }
}
