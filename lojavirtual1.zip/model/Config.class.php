<?php

Class Config {

//Informções básicas do site.
//const SITE_URL = "http://localhost";
    const SITE_PASTA = "lojavirtual";
    const SITE_NOME = "Loja DIMTech";
    const SITE_EMAIL_ADMIN = "douglas.dimtech@gmail.com";
    const BD_LIMIT_POR_PAG = 6;
    const SITE_CEP = 37904567;
//Informações do Banco de dados localhost.
//const BD_HOST = "localhost";
//const BD_USER = "root";
//const BD_SENHA = "";
//const BD_BANCO = "loja_dimtech";
//const BD_PREFIX = "lv_";
//Informações do Banco de dados servidor. - HOSTGATOR
    const SITE_URL = "http://dimtech.com.br";
    const BD_HOST = "108.179.252.20";
    const BD_USER = "dimtec93_lojavir";
    const BD_SENHA = "030182dtb";
    const BD_BANCO = "dimtec93_lojavirtual";
    const BD_PREFIX = "lv_";
//Informações do Banco de dados servidor. UOL HOST
//const SITE_URL = "http://dimtech.com.br";
//const BD_HOST = "dimtec93lojavir.mysql.uhserver.com";
//const BD_USER = "dimtec93lojavir";
//const BD_SENHA = "030182.dtb";
//const BD_BANCO = "dimtec93lojavir";
//const BD_PREFIX = "lv_";
//Informações para PHP MAILLER
    const EMAIL_HOST = "smtp.gmail.com";
    const EMAIL_USER = "douglas.dimtech@gmail.com";
    const EMAIL_NOME = "Loja DIMTech";
    const EMAIL_SENHA = "030182dtb";
    const EMAIL_PORTA = "587";
    const EMAIL_SMTPAUTH = true;
    const EMAIL_SMTPSECURE = "tls";
    const EMAIL_COPIA = "douglas.dimtech@gmail.com";
    //CONSTANTES PARA O PAGSEGURO
    const PS_EMAIL = "douglasborgesegidio@gmail.com"; // email pagseguro
    const PS_TOKEN = "9ec9ef4b-bd81-4212-9891-faf63ee6c20b56838a3049e78237641f27b4728e3e0a6f99-ce82-44db-8e2a-d892277179fe"; // token produção
    const PS_TOKEN_SBX = "";  // token do sandbox
    const PS_AMBIENTE = "production"; // production   /  sandbox

}
