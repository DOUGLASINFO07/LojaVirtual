<?php

$smarty = new Template();

Login::MenuCliente();

$smarty->display('view/minha_conta.tpl');

