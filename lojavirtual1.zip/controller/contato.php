<?php

$smarty = new Template();
$smarty->assign('CONTATO', 'Página de Contato');
$smarty->display('view/contato.tpl');


